python scripts/search/DropNAS.py --cfg configs/search/dropnas_darts_cifar10.yaml OUT_DIR exp/search/dropnas_darts_cifar10
