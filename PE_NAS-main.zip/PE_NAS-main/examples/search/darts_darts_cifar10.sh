python scripts/search/DARTS.py --cfg configs/search/darts_darts_cifar10.yaml OUT_DIR exp/search/darts_darts_cifar10
