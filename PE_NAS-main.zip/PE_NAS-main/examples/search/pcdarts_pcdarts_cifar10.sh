python scripts/search/PCDARTS.py --cfg configs/search/pcdarts_pcdarts_cifar10.yaml OUT_DIR exp/search/pcdarts_pcdarts_cifar10
