python scripts/search/DrNAS.py --cfg configs/search/snas_nasbench201_cifar10.yaml OUT_DIR exp/search/snas_nasbench201_cifar10
