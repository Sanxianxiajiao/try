python scripts/search/DrNAS.py --cfg configs/search/DrNAS/drnas_nasbench201_cifar100.yaml OUT_DIR exp/search/drnas_nasbench201_cifar100
