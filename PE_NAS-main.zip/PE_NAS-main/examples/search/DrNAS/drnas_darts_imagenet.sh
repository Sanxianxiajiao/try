python scripts/search/DrNAS.py --cfg configs/search/DrNAS/drnas_darts_imagenet.yaml OUT_DIR exp/search/drnas_darts_imagenet
