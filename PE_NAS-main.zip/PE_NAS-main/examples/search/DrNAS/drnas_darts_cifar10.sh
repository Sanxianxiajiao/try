python scripts/search/DrNAS.py --cfg configs/search/DrNAS/drnas_darts_cifar10.yaml OUT_DIR exp/search/drnas_darts_cifar10
