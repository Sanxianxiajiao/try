python scripts/search/DrNAS.py --cfg configs/search/DrNAS/drnas_nasbench201_cifar10_progressive.yaml OUT_DIR exp/search/drnas_nasbench201_cifar10_progressive
