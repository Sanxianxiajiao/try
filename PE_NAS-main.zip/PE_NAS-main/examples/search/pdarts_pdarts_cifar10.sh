python scripts/search/PDARTS.py --cfg configs/search/pdarts_pdarts_cifar10.yaml OUT_DIR exp/search/pdarts_pdarts_cifar10
