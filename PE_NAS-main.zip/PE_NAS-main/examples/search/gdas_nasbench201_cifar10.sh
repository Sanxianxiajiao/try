python scripts/search/DrNAS.py --cfg configs/search/gdas_nasbench201_cifar10.yaml OUT_DIR exp/search/gdas_nasbench201_cifar10
