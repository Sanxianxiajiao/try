echo `cd xnas/algorithms/RMINAS/teacher_model/resnet20_cifar10 && wget http://cdn.thrase.cn/rmi/resnet20.th`
echo `cd xnas/algorithms/RMINAS/teacher_model/nb201model_imagenet16120 && wget http://cdn.thrase.cn/rmi/009930-FULL.pth`
echo `cd xnas/algorithms/RMINAS/teacher_model/fbresnet_imagenet && wget http://cdn.thrase.cn/rmi/fbresnet152.pth`
echo `cd xnas/algorithms/RMINAS/teacher_model/resnet101_cifar100 && wget http://cdn.thrase.cn/rmi/resnet101.pth`
echo "Finish downloading weight files."
